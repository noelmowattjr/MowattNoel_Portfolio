﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("My name is Noel Mowatt");
            Console.Write(" and I am in Full Sail's Mobile Development Program.\r\n");
            Console.Write("These are the things I like to do for fun are:\r\n");
            Console.WriteLine(" *" + " Learning new software!");
            Console.WriteLine(" *" + " Going to the movies!");
            Console.WriteLine(" *" + " Playing billiards");
            Console.WriteLine(" *" + " Hanging on the Beach\r\n");
            Console.WriteLine("If I were ever stuck on some desserted island and could only have a few items,");
            Console.WriteLine("the items I would want in my possession are:\r\n 1) A 3 liter Sprite soda\r\n 2) A book titled: Survival Hacks - Over 200 Ways to Use Everyday Items for Wilderness Survival");
            Console.WriteLine(" 3) And an Album I would absolutely need is Kanye's Life of Pablo");
        }
    }
}
